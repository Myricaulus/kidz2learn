using System.ComponentModel;
using System.Drawing;
using System.Reflection.Metadata;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Kidz2Learn.Layout;
using Kidz2Learn.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;
using Tavenem.Blazor.IndexedDB;
using Tavenem.DataStorage;

namespace Kidz2Learn.Pages;
   public partial class SilbenChallenge : ComponentBase
   {
   // Pool: Dateiname = exakt die Silbe
    [Inject]
    private IJSRuntime Js { get; set; } = null!;
    List<string> SyllablePool = new()
    {
        "mi", "im", "ma", "am", "mo", "om"
    };

    string CurrentAudio = string.Empty;
    string CorrectSyllable = string.Empty;

    List<string> CurrentOptions = new();

    bool ShowFeedback = false;
    string FeedbackText = string.Empty;
    string FeedbackClass = string.Empty;

    int CorrectCount = 0;
    int WrongCount = 0;

    Random rng = new();

    protected override void OnInitialized()
    {
        NextTask();
    }

    void NextTask()
    {
        // 1. Silbe auswählen
        CorrectSyllable = SyllablePool[rng.Next(SyllablePool.Count)];
        CurrentAudio = $"audio/{CorrectSyllable}.wav";

        // 2. Optionspool vorbereiten
        //    1 richtige + 3 zufällige andere
        var shuffled = SyllablePool.OrderBy(_ => rng.Next()).ToList();

        CurrentOptions = shuffled
            .Where(s => s != CorrectSyllable)
            .Take(3)
            .Append(CorrectSyllable)
            .OrderBy(_ => rng.Next())
            .ToList();
    }

    async Task PlayAudio()
    {
        await Js.InvokeVoidAsync("k4l_playAudio", "audioPlayer");
    }

    void CheckAnswer(string answer)
    {
        bool correct = answer == CorrectSyllable;

        if (correct)
        {
            CorrectCount++;
            FeedbackText = "Richtig!";
            FeedbackClass = "k4l-feedback-correct";
        }
        else
        {
            WrongCount++;
            FeedbackText = $"Falsch – das war '{CorrectSyllable}'.";
            FeedbackClass = "k4l-feedback-wrong";
        }

        ShowFeedback = true;
        StateHasChanged();

        _ = Task.Delay(900).ContinueWith(_ =>
        {
            ShowFeedback = false;
            NextTask();
            InvokeAsync(StateHasChanged);
        });
    }

    private string GetColoredHtml(string silbe)
    {
        var result = "";

        foreach (var c in silbe)
        {
            if ("aeiouäöüAEIOUÄÖÜ".Contains(c))
            {
                // Vokal
                result += $"<span style='color:#0077ff;font-weight:bold'>{c}</span>";
            }
            else
            {
                // Konsonant
                result += $"<span style='color:#ff0066;font-weight:bold'>{c}</span>";
            }
        }

        return result;
    }
}
